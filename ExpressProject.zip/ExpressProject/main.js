const express = require('express');
const app = express();
const productRouter = require('./routes/products');

const mainRouter = require('./routes/index');
const { name } = require('ejs');
const apiKeyMiddleware = require('./middleware/apiKye');

// Setting up EJS as the template engine
app.set('view engine', 'ejs');
// Uncomment and adjust the following line if your views are in a different directory
// app.set('views', __dirname + '/templates');
console.log(app.get('views'));

// Serving static files from the 'public' directory
app.use(express.static('public'));
app.use('/en', mainRouter);
app.use(productRouter);

// Route for the home page
app.get('/', (req, res) => {
    res.render('index', {
        title: 'My Home page'
    });
});

// Route for the about page
app.get('/about', (req, res) => {
    res.render('about', {
        title: 'My About page'
    });
});

// Route to download a file
app.get('/download', (req, res) => {
    res.download('/about', {root: __dirname}); // Corrected path
    // res.download(__dirname + '/about.ejs'); // Corrected path

});

// API route
app.get('/api/products', apiKeyMiddleware, (req, res) => {
    res.json([
        {
            id: '123',
            name: 'Chrome'
        },
        {
            id: '124',
            name: 'Firefox'
        }
    ]);
});

// Start the server
app.listen(3000, () => {
    console.log('Server is listening on port 3000');
});
